//
// Created by aml on 28/05/2026.
//

#include "FuncionesAuxiliares.hpp"

void modificar_nombre(char *nombre) {
    for (int i=0; nombre[i]; i++) {
        if (nombre[i] >= 'a' && nombre[i] <= 'z') {
            nombre[i]= ' ';
        }
    }
}

int longitud(char *cadena) {
    int i=0;
    for (i=0; cadena[i]; i++);
    return i;
}

void copiar (char *destino, const char *fuente) {
    int i=0;
    for (i=0; fuente[i]; i++) {
        destino[i] = fuente[i];
    }
    destino[i] = "\0";
}
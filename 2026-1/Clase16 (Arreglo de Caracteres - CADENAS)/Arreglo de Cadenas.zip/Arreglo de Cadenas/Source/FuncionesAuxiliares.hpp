//
// Created by aml on 28/05/2026.
//

#ifndef ARREGLO_DE_CADENAS_FUNCIONESAUXILIARES_HPP
#define ARREGLO_DE_CADENAS_FUNCIONESAUXILIARES_HPP

#include "Utils.hpp"

void modificar_nombre(char *nombre);
int longitud(char *cadena);
void copiar (char *destino, const char *fuente);
#endif //ARREGLO_DE_CADENAS_FUNCIONESAUXILIARES_HPP
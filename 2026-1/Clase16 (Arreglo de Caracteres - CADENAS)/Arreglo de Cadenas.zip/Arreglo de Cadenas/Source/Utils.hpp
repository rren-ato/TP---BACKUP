//
// Created by aml on 28/05/2026.
//

#ifndef ARREGLO_DE_CADENAS_UTILS_HPP
#define ARREGLO_DE_CADENAS_UTILS_HPP

#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>

using namespace std;

#endif //ARREGLO_DE_CADENAS_UTILS_HPP
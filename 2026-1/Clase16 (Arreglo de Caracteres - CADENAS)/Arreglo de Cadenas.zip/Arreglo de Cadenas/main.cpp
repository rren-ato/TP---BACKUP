#include "Source/FuncionesAuxiliares.hpp"

int main() {
    char nombre_1[30];
    char nombre_2[30];

    cin >> nombre_1;
    cout << nombre_1 << endl;
    modificar_nombre(nombre_1);
    cout << nombre_1 << endl;


    //Forma correcta de guardar info volatil
    nombre_2[0] = 'A';
    nombre_2[1] = 'N';
    nombre_2[2] = 'A';
    nombre_2[3] = '\0';
    cout << nombre_2 << endl;
    //camelizar(nombre_1)

    //TAMAÑO LONGITUD - CADENA

    char apellido [30] = "Gomez\0";
    cout << apellido << endl;
    int n = longitud(nombre_1);
    cout << "Hecho a mano: " << n << endl;
    cout << "Usando Libreria: " << strlen(apellido) << endl;


    //Copia de una CADENA vs LIBRERIA
    char nombre[30];
    copiar (nombre, "Erasmo Gomez");
    cout << nombre << endl;
    strcpy(nombre, "Miguel Guanira");
    cout << nombre << endl;
    return 0;
}